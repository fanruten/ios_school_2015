//
//  Utilities.m
//  FilesSample
//
// Created by Dmitry Zakharov on 4/10/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


#import "Utilities.h"


@implementation Utilities

+ (NSURL *)buildURLWithFileName:(NSString *)fileName {
    return [[[self baseURL] URLByAppendingPathComponent:fileName isDirectory:NO] URLByAppendingPathExtension:@"dat"];
}

+ (NSURL *)baseURL {
    static NSURL *baseURL;

    return baseURL ?: (baseURL = ({
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSURL *applicationSupportDirectory = [fileManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
        NSURL *bundleDirectory = [applicationSupportDirectory URLByAppendingPathComponent:[NSBundle mainBundle].bundleIdentifier isDirectory:YES];

        __autoreleasing NSError *error;
        if (![fileManager createDirectoryAtURL:bundleDirectory withIntermediateDirectories:YES attributes:nil error:&error] && [self isFileExistsError:error]) {
            NSLog(@"Unable to create directory at URL \'%@\': %@", bundleDirectory, error);
            abort();
        }

        bundleDirectory;
    }));
};

+ (BOOL)isFileExistsError:(NSError *)error {
    return error.domain == NSCocoaErrorDomain && error.code == NSFileWriteFileExistsError;
}

@end

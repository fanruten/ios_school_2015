//
//  DirectoriesSampleViewController.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/9/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import "DirectoriesSampleViewController.h"

@interface DirectoriesSampleViewController ()

@property (nonatomic, weak) IBOutlet UITextView *resultTextView;

@end

@implementation DirectoriesSampleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.resultTextView.text = [[self directoryLines] componentsJoinedByString:@"\n\n"];
}

- (NSArray *)directoryLines {
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    
    NSSearchPathDirectory directories[] = {
        NSApplicationDirectory,            // supported applications (Applications)
        NSDemoApplicationDirectory,        // unsupported applications, demonstration versions (Demos)
        NSDeveloperApplicationDirectory,   // developer applications (Developer/Applications). DEPRECATED - there is no one single Developer directory.
        NSAdminApplicationDirectory,       // system and network administration applications (Administration)
        NSLibraryDirectory,                // various documentation, support, and configuration files, resources (Library)
        NSDeveloperDirectory,              // developer resources (Developer) DEPRECATED - there is no one single Developer directory.
        NSUserDirectory,                   // user home directories (Users)
        NSDocumentationDirectory,          // documentation (Documentation)
        NSDocumentDirectory,               // documents (Documents)
        NSCoreServiceDirectory,            // location of CoreServices directory (System/Library/CoreServices)
        NSAutosavedInformationDirectory,   // location of autosaved documents (Documents/Autosaved)
        NSDesktopDirectory,                // location of user's desktop
        NSCachesDirectory,                 // location of discardable cache files (Library/Caches)
        NSApplicationSupportDirectory,     // location of application support files (plug-ins, etc) (Library/Application Support)
        NSDownloadsDirectory,              // location of the user's "Downloads" directory
        NSInputMethodsDirectory,           // input methods (Library/Input Methods)
        NSMoviesDirectory,                 // location of user's Movies directory (~/Movies)
        NSMusicDirectory,                  // location of user's Music directory (~/Music)
        NSPicturesDirectory,               // location of user's Pictures directory (~/Pictures)
        NSPrinterDescriptionDirectory,     // location of system's PPDs directory (Library/Printers/PPDs)
        NSSharedPublicDirectory,           // location of user's Public sharing directory (~/Public)
        NSPreferencePanesDirectory,        // location of the PreferencePanes directory for use with System Preferences (Library/PreferencePanes)
        NSItemReplacementDirectory,        // For use with NSFileManager's URLForDirectory:inDomain:appropriateForURL:create:error:
        NSAllApplicationsDirectory,        // all directories where applications can occur
        NSAllLibrariesDirectory,           // all directories where resources can occur
    };
    
    size_t length = sizeof(directories) / sizeof(*directories);
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:length];
    
    for (size_t directoryType = 0; directoryType < length; ++directoryType) {
        // Get the URL for type.
        NSString *directoryName = [self nameForValue:directories[directoryType]];
        NSURL *directoryURL = [fileManager URLsForDirectory:directories[directoryType] inDomains:NSUserDomainMask].firstObject;
        NSString *path = directoryURL.path;

//        NSString *path = [self shortenPath:directoryURL];

        [result addObject:[self formatResultWithDirectoryName:directoryName directoryString:path]];
    }

    NSString *homeDir = [NSURL fileURLWithPath:NSHomeDirectory() isDirectory:YES].path;
    NSString *tmpDir = [NSURL fileURLWithPath:NSTemporaryDirectory() isDirectory:YES].path;

//    NSString *homeDir = [self shortenPath:[NSURL fileURLWithPath:NSHomeDirectory() isDirectory:YES]];
//    NSString *tmpDir = [self shortenPath:[NSURL fileURLWithPath:NSTemporaryDirectory() isDirectory:YES]];

    [result addObject:[self formatResultWithDirectoryName:@"Home" directoryString:homeDir]];
    [result addObject:[self formatResultWithDirectoryName:@"Temp" directoryString:tmpDir]];
    
    return [result copy];
}

- (NSString *)shortenPath:(NSURL *)URL __used {
    NSArray *components = URL.pathComponents;
    return [(components.count > 3
            ? [components subarrayWithRange:NSMakeRange(components.count - 3, 3)]
            : components) componentsJoinedByString:@"/"];
}

- (NSString *)nameForValue:(NSSearchPathDirectory)value {
#define LITERAL(value) @#value
    return (NSString *[]) {
        [NSApplicationDirectory] = LITERAL(NSApplicationDirectory),
        [NSDemoApplicationDirectory] = LITERAL(NSDemoApplicationDirectory),
        [NSDeveloperApplicationDirectory] = LITERAL(NSDeveloperApplicationDirectory),
        [NSAdminApplicationDirectory] = LITERAL(NSAdminApplicationDirectory),
        [NSLibraryDirectory] = LITERAL(NSLibraryDirectory),
        [NSDeveloperDirectory] = LITERAL(NSDeveloperDirectory),
        [NSUserDirectory] = LITERAL(NSUserDirectory),
        [NSDocumentationDirectory] = LITERAL(NSDocumentationDirectory),
        [NSDocumentDirectory] = LITERAL(NSDocumentDirectory),
        [NSCoreServiceDirectory] = LITERAL(NSCoreServiceDirectory),
        [NSAutosavedInformationDirectory] = LITERAL(NSAutosavedInformationDirectory),
        [NSDesktopDirectory] = LITERAL(NSDesktopDirectory),
        [NSCachesDirectory] = LITERAL(NSCachesDirectory),
        [NSApplicationSupportDirectory] = LITERAL(NSApplicationSupportDirectory),
        [NSDownloadsDirectory] = LITERAL(NSDownloadsDirectory),
        [NSInputMethodsDirectory] = LITERAL(NSInputMethodsDirectory),
        [NSMoviesDirectory] = LITERAL(NSMoviesDirectory),
        [NSMusicDirectory] = LITERAL(NSMusicDirectory),
        [NSPicturesDirectory] = LITERAL(NSPicturesDirectory),
        [NSPrinterDescriptionDirectory] = LITERAL(NSPrinterDescriptionDirectory),
        [NSSharedPublicDirectory] = LITERAL(NSSharedPublicDirectory),
        [NSPreferencePanesDirectory] = LITERAL(NSPreferencePanesDirectory),
        [NSItemReplacementDirectory] = LITERAL(NSItemReplacementDirectory),
        [NSAllApplicationsDirectory] = LITERAL(NSAllApplicationsDirectory),
        [NSAllLibrariesDirectory] = LITERAL(NSAllLibrariesDirectory)
    }[value];
#undef LITERAL
}

- (NSString *)formatResultWithDirectoryName:(NSString *)directoryName directoryString:(NSString *)directoryString {
    return [NSString stringWithFormat:@"%@:\t%@", directoryName, directoryString];
}

@end

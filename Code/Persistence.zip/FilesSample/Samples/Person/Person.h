//
//  Person.h
//  FilesSample
//
// Created by Dmitry Zakharov on 4/9/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


@import Foundation;


@interface Person : NSObject

@property (nonatomic, readonly, copy) NSString *name;
@property (nonatomic, readonly, copy) NSArray *friends;
@property (nonatomic, readonly) NSUInteger age;

- (instancetype)initWithName:(NSString *)name age:(NSUInteger)age;

- (void)addFriend:(Person *)friend;

+ (void)make:(Person *)person1 friendOf:(Person *)person2;

@end

//
//  CodingPerson.m
//  FilesSample
//
// Created by Dmitry Zakharov on 4/9/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


#import "CodingPerson.h"
#import "Utilities.h"


@implementation CodingPerson

- (id)initWithCoder:(NSCoder *)coder {
    NSString *name = [coder decodeObjectForKey:SELECTOR_NAME(name)];
    NSUInteger age = (NSUInteger) [coder decodeIntegerForKey:SELECTOR_NAME(age)];
    NSArray *friends = [coder decodeObjectForKey:SELECTOR_NAME(friends)];

    self = [self initWithName:name age:age];
    // self = [super initWithCoder:coder];
    if (self) {
        for (Person *person in friends) {
            [self addFriend:person];
        }
    }

    return self;
}

- (void)encodeWithCoder:(NSCoder *)coder {
    // [super encodeWithCoder:coder];
    [coder encodeObject:self.name forKey:SELECTOR_NAME(name)];
    [coder encodeInteger:self.age forKey:SELECTOR_NAME(age)];
    [coder encodeObject:self.friends forKey:SELECTOR_NAME(friends)];
}

@end

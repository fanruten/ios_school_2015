//
//  Person.m
//  FilesSample
//
// Created by Dmitry Zakharov on 4/9/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


#import "Person.h"


@interface Person ()

@property (nonatomic, copy) NSArray *friends;

@end

@implementation Person

- (instancetype)initWithName:(NSString *)name age:(NSUInteger)age {
    self = [super init];
    if (self) {
        _name = [name copy];
        _age = age;
        _friends = @[ ];
    }

    return self;
}

- (void)addFriend:(Person *)friend {
     self.friends = [self.friends arrayByAddingObject:friend];
}

+ (void)make:(Person *)person1 friendOf:(Person *)person2 {
    [person1 addFriend:person2];
    [person2 addFriend:person1];
}

- (NSString *)description {
    return [NSString stringWithFormat:
            @"Person (name = \'%@\', age = \'%tu\', names of friends = \'%@\')",
                    self.name,
                    self.age,
                    [[self.friends valueForKey:@"name"] componentsJoinedByString:@", "]];
}

@end

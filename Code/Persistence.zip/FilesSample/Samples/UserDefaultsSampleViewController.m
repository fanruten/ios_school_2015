//
//  UserDefaultsSampleViewController.m
//  FilesSample
//
// Created by Dmitry Zakharov on 4/10/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


#import "UserDefaultsSampleViewController.h"


@implementation UserDefaultsSampleViewController

- (IBAction)storeButtonTapped {
    [self registerDefaults];

    NSLog(@"Default Tutor name: %@", [[NSUserDefaults standardUserDefaults] stringForKey:@"Tutor name"]);
    NSLog(@"Other sessions: %@", [[NSUserDefaults standardUserDefaults] arrayForKey:@"All sessions"]);

    [[NSUserDefaults standardUserDefaults] setObject:@"Ruslan" forKey:@"Tutor name"];
}

- (IBAction)loadButtonTapped {
    [self registerDefaults];
    NSString *tutorName = [[NSUserDefaults standardUserDefaults] stringForKey:@"Tutor name"];
    NSLog(@"Tutor name: %@", tutorName);
}

- (void)registerDefaults {
    NSURL *defaultsURL = [[NSBundle mainBundle] URLForResource:@"configuration" withExtension:@"plist"];
    NSDictionary *defaults = [NSDictionary dictionaryWithContentsOfURL:defaultsURL];
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaults];
}

@end

//
//  OrganizationsTableViewController.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/10/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import "OrganizationsTableViewController.h"
#import "ManagedObjectContextProvider.h"


@interface OrganizationsTableViewController ()

@property (nonatomic) NSArray *organizations;

@end

@implementation OrganizationsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.organizations = [self loadOrganizations];
}

- (NSArray *)loadOrganizations {
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"Organization"];
    return [[ManagedObjectContextProvider sharedInstence].mainContext executeFetchRequest:request error:NULL];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.organizations.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrganizationCell" forIndexPath:indexPath];
    cell.textLabel.text = [self.organizations[ (NSUInteger) indexPath.row ] name];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSManagedObjectID *organizationMOID = [self.organizations[(NSUInteger) indexPath.row] objectID];
    
    if (self.completionBlock) {
        self.completionBlock(organizationMOID);
    }
}

- (NSManagedObjectContext *)createManagedObjectContext {
    return [ManagedObjectContextProvider sharedInstence].mainContext;
}

@end

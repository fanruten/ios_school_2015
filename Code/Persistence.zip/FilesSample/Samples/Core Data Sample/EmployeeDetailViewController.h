//
//  EmployeeDetailViewController.h
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/10/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

@import UIKit;
@import CoreData;


@interface EmployeeDetailViewController : UIViewController

@property (nonatomic) NSManagedObjectID *employeeMOID;

@property (nonatomic, copy) void (^completionBlock)();

@end

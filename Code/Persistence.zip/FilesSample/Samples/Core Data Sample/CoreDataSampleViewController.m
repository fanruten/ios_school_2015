//
//  CoreDataSampleViewController.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/10/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

@import CoreData;
#import "CoreDataSampleViewController.h"
#import "EmployeeDetailViewController.h"
#import "Employee.h"
#import "Utilities.h"
#import "ManagedObjectContextProvider.h"


@interface CoreDataSampleViewController () <NSFetchedResultsControllerDelegate>

@property (nonatomic) NSFetchedResultsController *fetchedResultsController;

@end

@implementation CoreDataSampleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:self.createFetchRequest
                                                                        managedObjectContext:self.createManagedObjectContext
                                                                          sectionNameKeyPath:nil
                                                                                   cacheName:nil];
    self.fetchedResultsController.delegate = self;
    [self loadItems];
}

- (void)loadItems {
    [self.fetchedResultsController performFetch:NULL];
}

- (NSFetchRequest *)createFetchRequest {
    NSFetchRequest *request = [[NSFetchRequest alloc] initWithEntityName:CLASS_NAME(Employee)];
    request.relationshipKeyPathsForPrefetching = @[ SELECTOR_NAME(organization) ];
    request.sortDescriptors = @[ [NSSortDescriptor sortDescriptorWithKey:SELECTOR_NAME(name) ascending:YES] ];
    return request;
}

- (NSManagedObjectContext *)createManagedObjectContext {
    return [ManagedObjectContextProvider sharedInstence].mainContext;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    id<NSFetchedResultsSectionInfo> sections = self.fetchedResultsController.sections[ (NSUInteger) section ];
    return sections.numberOfObjects;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EmployeeCell" forIndexPath:indexPath];

    Employee *employee = (Employee *) [self.fetchedResultsController objectAtIndexPath:indexPath];
    cell.textLabel.text = employee.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d", employee.salary];

    return cell;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSString *segueIdentifier = segue.identifier;

    EmployeeDetailViewController *controller;
    if ([segueIdentifier isEqualToString:@"Edit employee"]) {
        __unused NSIndexPath *cellIndexPath = [self.tableView indexPathForCell:sender];

        controller = segue.destinationViewController;
        controller.employeeMOID = nil;
    } else if ([segueIdentifier isEqualToString:@"New employee"]) {
        controller = (EmployeeDetailViewController *) [segue.destinationViewController topViewController];
    }
    controller.completionBlock = ^{
        [self loadItems];
    };
}

@end

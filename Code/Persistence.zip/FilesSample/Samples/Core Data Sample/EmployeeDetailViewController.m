//
//  EmployeeDetailViewController.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/10/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import "EmployeeDetailViewController.h"
#import "OrganizationsTableViewController.h"
#import "Employee.h"
#import "Organization.h"
#import "ManagedObjectContextProvider.h"


@interface EmployeeDetailViewController ()

@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *salaryField;
@property (weak, nonatomic) IBOutlet UIButton *organizationButton;

@property (nonatomic) Employee *employee;
@property (nonatomic) NSManagedObjectContext *context;

@end

@implementation EmployeeDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (!self.navigationItem.backBarButtonItem) {
        self.navigationItem.leftBarButtonItem = [self cancelButton];
    }
    self.context = [self createManagedObjectContext];
    self.employee = self.employeeMOID ? [self loadEmployeeWithID:self.employeeMOID] : [self createEmployee];
}

- (UIBarButtonItem *)cancelButton {
    return [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(close)];
}

- (void)close {
    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (BOOL)save {
    self.employee.name = self.nameField.text;
    self.employee.salary = self.salaryField.text.integerValue;

    NSError *error;
    BOOL result = [self.context save:&error];
    return result;
}

- (IBAction)doneButtonTapped {
    if ([self save]) {
        self.completionBlock();
        if (self.employeeMOID) {
            // Was in Edit mode.
            [self.navigationController popViewControllerAnimated:YES];
        } else {
            // Was in New mode.
            [self dismissViewControllerAnimated:YES completion:NULL];
        }
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"Organization Selection"]) {
        OrganizationsTableViewController *controller = segue.destinationViewController;
        controller.completionBlock = ^(NSManagedObjectID *selectedOrganization) {
            self.employee.organization = [self organizationByMOID:selectedOrganization];
            [self.organizationButton setTitle:self.employee.organization.name forState:UIControlStateNormal];
        };
    }
}

- (Organization *)organizationByMOID:(NSManagedObjectID *)organizationMOID {
    return (Organization *)[self.context objectWithID:organizationMOID];
}

- (Employee *)createEmployee {
    Employee *employee = [NSEntityDescription insertNewObjectForEntityForName:@"Employee" inManagedObjectContext:self.context];
    return employee;
}

- (Employee *)loadEmployeeWithID:(NSManagedObjectID *)MOID {
    return nil;
}

- (NSManagedObjectContext *)createManagedObjectContext {
    return [ManagedObjectContextProvider sharedInstence].mainContext;
}

@end

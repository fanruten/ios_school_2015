//
//  ManagedObjectContextProvider.m
//  FilesSample
//
// Created by Dmitry Zakharov on 4/10/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


#import "ManagedObjectContextProvider.h"
#import "Utilities.h"
#import "Organization.h"


@interface ManagedObjectContextProvider ()

@property (nonatomic, readonly) NSPersistentStoreCoordinator *coordinator;

@end

@implementation ManagedObjectContextProvider

- (instancetype)initInternal {
    self = [super init];
    if (self) {
        NSManagedObjectModel *model = [NSManagedObjectModel mergedModelFromBundles:@[ [NSBundle mainBundle] ]];
        _coordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:model];
        __autoreleasing NSError *error;
        if (![self.coordinator addPersistentStoreWithType:NSSQLiteStoreType
                                            configuration:nil
                                                      URL:self.storeURL
                                                  options:self.coordinatorOptions
                                                    error:&error]) {
            NSLog(@"Error: %@", error);
            return (self = nil);
        }
    }

    [Organization loadOrganizationsInContext:self.mainContext];

    return self;
}

- (NSURL *)storeURL {
    return [Utilities buildURLWithFileName:@"Model"];
}

- (NSDictionary *)coordinatorOptions {
    return @{
            NSInferMappingModelAutomaticallyOption : @YES,
            NSMigratePersistentStoresAutomaticallyOption : @YES
    };
}

+ (instancetype)sharedInstence {
    static dispatch_once_t token;

    static ManagedObjectContextProvider *instance;
    dispatch_once(&token, ^{
        instance = [[self alloc] initInternal];
    });

    return instance;
}

- (NSManagedObjectContext *)mainContext {
    NSManagedObjectContext *context = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    context.persistentStoreCoordinator = self.coordinator;
    return context;
}

@end

//
//  Employee.h
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/11/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Organization;

@interface Employee : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic) int32_t salary;
@property (nonatomic, retain) Organization *organization;

@end

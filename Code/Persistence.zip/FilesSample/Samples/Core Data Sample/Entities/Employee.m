//
//  Employee.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/11/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import "Employee.h"
#import "Organization.h"


@implementation Employee

@dynamic name;
@dynamic salary;
@dynamic organization;

@end

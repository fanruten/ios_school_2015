//
//  Organization.h
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/11/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Employee;

@interface Organization : NSManagedObject

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSSet *employees;

+ (void)loadOrganizationsInContext:(NSManagedObjectContext *)context;

@end

@interface Organization (CoreDataGeneratedAccessors)

- (void)addEmployeesObject:(Employee *)value;
- (void)removeEmployeesObject:(Employee *)value;
- (void)addEmployees:(NSSet *)values;
- (void)removeEmployees:(NSSet *)values;

@end

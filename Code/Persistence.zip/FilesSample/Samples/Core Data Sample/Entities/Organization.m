//
//  Organization.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/11/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import "Organization.h"
#import "Employee.h"


@implementation Organization

@dynamic name;
@dynamic employees;

+ (void)loadOrganizationsInContext:(NSManagedObjectContext *)context {
    if ([context countForFetchRequest:[NSFetchRequest fetchRequestWithEntityName:@"Organization"] error:NULL] > 0) {
        return;
    }

    for (NSString *name in @[ @"Organization 1", @"Organization 2", @"Organization 3", ]) {
        Organization *organization = [NSEntityDescription insertNewObjectForEntityForName:@"Organization" inManagedObjectContext:context];
        organization.name = name;
    }
    NSError *error;
    [context save:&error];
    if (error) {
        ;
    }
}

@end

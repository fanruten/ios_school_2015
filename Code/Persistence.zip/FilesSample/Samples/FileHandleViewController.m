//
//  FileHandleViewController.m
//  FilesSample
//
// Created by Dmitry Zakharov on 4/10/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


#import "FileHandleViewController.h"
#import "Utilities.h"


@interface FileHandleViewController ()

@property (nonatomic) NSUInteger totalSize;
@property (nonatomic) NSUInteger times;

@property (nonatomic, weak) IBOutlet UILabel *sizeCounter;

@end

@implementation FileHandleViewController

- (IBAction)copyButtonTapped {
    NSURL *fromFileURL = [[NSBundle mainBundle] URLForResource:@"Lord of the rings" withExtension:@"txt"];
    NSURL *toFileURL = [self toFileURL];

    __autoreleasing NSError *error;
    if (![[NSFileManager defaultManager] copyItemAtURL:fromFileURL toURL:toFileURL error:&error] && ![Utilities isFileExistsError:error]) {
        NSLog(@"Unable to copy file from \'%@\' to \'%@\': %@", fromFileURL, toFileURL, error);
    } else {
        NSLog(@"File copied to \'%@\'", toFileURL);
    }
}

- (IBAction)loadButtonTapped {
    __autoreleasing NSError *error;
    NSFileHandle *lotrFile = [NSFileHandle fileHandleForReadingFromURL:[self toFileURL] error:&error];
    if (error) {
        NSLog(@"Error opening file for reading: %@", error);
        return;
    }

    self.totalSize = 0;
    self.times = 0;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fileRead:) name:NSFileHandleReadCompletionNotification object:lotrFile];
    [lotrFile readInBackgroundAndNotify];
}

- (void)fileRead:(NSNotification *)notification {
    NSData *data = notification.userInfo[NSFileHandleNotificationDataItem];
    NSFileHandle *handle = notification.object;

    NSUInteger sizeOfData = data.length;
    if (sizeOfData == 0) {
        // Done reading.
        self.view.backgroundColor = [UIColor greenColor];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:NSFileHandleReadCompletionNotification object:handle];
        [handle closeFile];
    } else {
        self.view.backgroundColor = [UIColor yellowColor];
        self.totalSize += sizeOfData;
        self.sizeCounter.text = [NSString stringWithFormat:@"%tu: %tu", ++self.times, self.totalSize];

        [handle readInBackgroundAndNotify];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (NSURL *)toFileURL {
    static NSURL *toFileURL;
    return toFileURL ?: (toFileURL = [[[Utilities buildURLWithFileName:@"lotr"] URLByDeletingPathExtension] URLByAppendingPathExtension:@"txt"]);
}

@end

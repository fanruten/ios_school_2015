//
//  FoundationSampleViewController.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/9/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import "FoundationSampleViewController.h"
#import "Utilities.h"


@implementation FoundationSampleViewController

- (IBAction)storeButtonTapped {
    NSString *string = @"This is a sample string";
    NSData *data = [@"This is a sample data" dataUsingEncoding:NSUTF8StringEncoding];
    NSArray *array = @[ @10, @"Second item" ];

    // Keys must be strings
    NSDictionary *dictionary = @{
            @"String" : @"Value 1",
            @"Date" : [NSDate dateWithTimeIntervalSinceReferenceDate:10000],
            // To store set, convert it to array
            @"SetAsArray" : [NSSet setWithObjects:@10, @20, nil].allObjects,
            @"Number" : @10,
            @"Bool" : @YES
    };

    // The things you may save in arrays and dictionaries:
    // NSString
    // NSData
    // NSArray
    // NSDictionary
    // NSDate
    // NSNumber for number
    // NSNumber for bool


    __autoreleasing NSError *error;
    if (![string writeToURL:self.stringURL atomically:YES encoding:NSUTF8StringEncoding error:&error] && error) {
        NSLog(@"Unable to write string: %@", error);
        error = nil;
    }

    if (![data writeToURL:self.dataURL options:NSDataWritingAtomic | NSDataWritingFileProtectionNone error:&error] && error) {
        NSLog(@"Unable to write data: %@", error);
        error = nil;
    }

    if (![array writeToURL:self.arrayURL atomically:YES]) {
        NSLog(@"Unable to write array!");
    }

    if (![dictionary writeToURL:self.dictionaryURL atomically:YES]) {
        NSLog(@"Unable to write dictionary!");
    } else {
        NSLog(@"Dictionary stored in %@", self.dictionaryURL);
    }

    NSLog(@"Done saving items");
}

- (NSURL *)stringURL {
    return [Utilities buildURLWithFileName:@"string"];
}

- (NSURL *)dataURL {
    return [Utilities buildURLWithFileName:@"data"];
}

- (NSURL *)arrayURL {
    return [Utilities buildURLWithFileName:@"array"];
}

- (NSURL *)dictionaryURL {
    return [Utilities buildURLWithFileName:@"dictionary"];
}

- (IBAction)loadButtonTapped {
    __autoreleasing NSError *error;
    NSString *string = [NSString stringWithContentsOfURL:self.stringURL encoding:NSUTF8StringEncoding error:&error];
    if (error) {
        NSLog(@"Unable to read string: %@", error);
        error = nil;
    } else {
        NSLog(@"The string: %@", string);
    }

    NSData *data = [NSData dataWithContentsOfURL:self.dataURL options:NSDataReadingMappedIfSafe error:&error];
    if (error) {
        NSLog(@"Unable to read data: %@", error);
        error = nil;
    } else {
        NSLog(@"The data: %@", [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
    }

    NSArray *array = [NSArray arrayWithContentsOfURL:self.arrayURL];
    if (array) {
        NSLog(@"The array: %@", array);
    } else {
        NSLog(@"Unable to read array!");
    }

    NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfURL:self.dictionaryURL];
    if (dictionary) {
        NSLog(@"The dictionary: %@", dictionary);
    } else {
        NSLog(@"Unable to read dictionary!");
    }

    NSLog(@"Done reading items");
}

@end

//
//  Utilities.h
//  FilesSample
//
// Created by Dmitry Zakharov on 4/10/15.
// Copyright (c) 2015 comfly. All rights reserved.
//


@import Foundation;


@interface Utilities : NSObject

+ (NSURL *)buildURLWithFileName:(NSString *)fileName;
+ (BOOL)isFileExistsError:(NSError *)error;

@end

#define SELECTOR_NAME(_selector) NSStringFromSelector(@selector(_selector))
#define CLASS_NAME(_class) NSStringFromClass([_class class])

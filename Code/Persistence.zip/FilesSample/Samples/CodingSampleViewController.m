//
//  CodingSampleViewController.m
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/10/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

#import "CodingSampleViewController.h"
#import "Person.h"
#import "Utilities.h"
#import "CodingPerson.h"


@interface CodingSampleViewController ()

@end

@implementation CodingSampleViewController

- (IBAction)storeButtonTapped {
    Person *sam;
    Person *joe;
    Person *jane;
    Person *mary;
    NSArray *people = @[
            sam = [[CodingPerson alloc] initWithName:@"Sam" age:30],
            joe = [[CodingPerson alloc] initWithName:@"Joe" age:28],
            jane = [[CodingPerson alloc] initWithName:@"Jane" age:27],
            mary = [[CodingPerson alloc] initWithName:@"Mary" age:29]
    ];

    [Person make:sam friendOf:joe];
    [Person make:sam friendOf:jane];
    [Person make:sam friendOf:mary];

    [Person make:joe friendOf:mary];

    if ([NSKeyedArchiver archiveRootObject:people toFile:[self fileURL].path]) {
        NSLog(@"File written successfully");
    } else {
        NSLog(@"Error writing file");
    }
}

- (IBAction)loadButtonTapped {
    NSArray *people = [NSKeyedUnarchiver unarchiveObjectWithFile:[self fileURL].path];
    NSLog(@"People: %@", people);
}

- (NSURL *)fileURL {
    NSURL *result = [Utilities buildURLWithFileName:@"people"];
    NSLog(@"File at: %@", result.path);
    return result;
}

@end

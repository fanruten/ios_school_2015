//
//  AppDelegate.h
//  FilesSample
//
//  Created by Dmitry Zakharov on 4/9/15.
//  Copyright (c) 2015 comfly. All rights reserved.
//

@import UIKit;


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic) UIWindow *window;

@end

